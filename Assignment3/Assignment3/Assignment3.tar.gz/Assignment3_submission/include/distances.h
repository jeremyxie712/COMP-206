#include "preferences.h"

double compute_difference_numeric( PREFERENCE_INFO *one, PREFERENCE_INFO *two );
double compute_difference_alphabetic( PREFERENCE_INFO *one, PREFERENCE_INFO *two );