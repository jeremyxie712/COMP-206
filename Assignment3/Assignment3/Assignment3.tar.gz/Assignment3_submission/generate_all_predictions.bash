for i in $(ls data)
do
	mv data/$i query
	./movie_recommender query/$i data/*
	mv query/$i data
done
